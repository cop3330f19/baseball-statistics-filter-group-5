#include "Filter.h"
#include <vector>
#include <iostream>
#include <string>

using namespace std;

static void sort(vector<BaseballStatistic>&);
static int search(vector<BaseballStatistic>, string, string);  

