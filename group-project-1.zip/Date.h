#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>
using namespace std;

class Date
{
	
	private:
		const int day, month, year;
    int birthMonth,birthDay,birthYear;
	
	public:
		//Constructor accepts the date in the format YYYY, MM, DD
		//eg Date date(2019, 9, 27);
		explicit Date(int y, int m, int d):
			year(y), month(m), day(d){}

		Date(int bmonth,int bday,int byear);
    
		int getDay()const; //Returns the day
		int getMonth()const; //Returns the month
		int getYear()const;//Returns the year
		std::string getDate()const;
    
    //Person's Birth Date
    int getBirthDay()const; //Returns the day
		int getBirthMonth()const;//Returns the month
		int getBirthYear()const; //Returns the year

		int getAge()const; //Calculates age in years
      
};
#endif